package core;

import models.Track;

import java.util.List;
import java.util.Map;

public class RePlayerImpl implements RePlayer {

    @Override
    public void addTrack(Track track, String album) {

    }

    @Override
    public void removeTrack(String trackTitle, String albumName) {

    }

    @Override
    public boolean contains(Track track) {
        return false;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public Track getTrack(String title, String albumName) {
        return null;
    }

    @Override
    public Iterable<Track> getAlbum(String albumName) {
        return null;
    }

    @Override
    public void addToQueue(String trackName, String albumName) {

    }

    @Override
    public Track play() {
        return null;
    }

    @Override
    public Iterable<Track> getTracksInDurationRangeOrderedByDurationThenByPlaysDescending(int lowerBound, int upperBound) {
        return null;
    }

    @Override
    public Iterable<Track> getTracksOrderedByAlbumNameThenByPlaysDescendingThenByDurationDescending() {
        return null;
    }

    @Override
    public Map<String, List<Track>> getDiscography(String artistName) {
        return null;
    }
}
