package core;

import models.Movie;

import java.util.*;

public class MovieDatabaseImpl implements MovieDatabase {
    @Override
    public void addMovie(Movie movie) {

    }

    @Override
    public void removeMovie(String movieId) {

    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean contains(Movie movie) {
        return false;
    }

    @Override
    public Iterable<Movie> getMoviesByActor(String actorName) {
        return null;
    }

    @Override
    public Iterable<Movie> getMoviesByActors(List<String> actors) {
        return null;
    }

    @Override
    public Iterable<Movie> getMoviesByYear(Integer releaseYear) {
        return null;
    }

    @Override
    public Iterable<Movie> getMoviesInRatingRange(double lowerBound, double upperBound) {
        return null;
    }

    @Override
    public Iterable<Movie> getAllMoviesOrderedByActorPopularityThenByRatingThenByYear() {
        return null;
    }
}
