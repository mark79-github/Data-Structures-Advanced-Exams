package core;

import models.Expression;

public class ExpressionistImpl implements Expressionist {
    @Override
    public void addExpression(Expression expression) {

    }

    @Override
    public void addExpression(Expression expression, String parentId) {

    }

    @Override
    public boolean contains(Expression expression) {
        return false;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public Expression getExpression(String expressionId) {
        return null;
    }

    @Override
    public void removeExpression(String expressionId) {

    }

    @Override
    public String evaluate() {
        return null;
    }
}
