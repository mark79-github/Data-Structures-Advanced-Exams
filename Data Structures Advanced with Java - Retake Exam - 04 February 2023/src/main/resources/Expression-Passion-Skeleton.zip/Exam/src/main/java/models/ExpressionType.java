package models;

public enum ExpressionType {
    OPERATOR,
    VALUE
}
